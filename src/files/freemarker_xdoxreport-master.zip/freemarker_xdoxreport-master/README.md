# freemarker_xdoxreport
freemarker xdocxreport word docx to pdf Ms Office 2007 -2013

通过freemarker 生成docx格式word，用xdocxreport 将docx格式word转换成pdf
